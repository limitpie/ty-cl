package com.example.table_;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.app.Activity;
import android.content.Intent;

public class TableDialog extends Activity {

	Button add;
	Button edit;
	Button delete;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTheme(R.style.NewActivity);
		setContentView(R.layout.dialog);
		
		add = (Button) findViewById(R.id.AddIcon);

		add.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				Intent myLocalIntent = getIntent();
				// look into the bundle sent to Activity2 for data items
				Bundle myBundle = myLocalIntent.getExtras();
				
				String day = myBundle.getString("day");
				String time = myBundle.getString("time");
				
				// create intent to call Activity2
				// pick call made to Activity2 via Intent
				Intent i = new Intent(TableDialog.this, Input.class);
				Bundle myData = new Bundle();
				myData.putString("day", day);
				myData.putString("time", time);
				i.putExtras(myData);
				startActivity(i);
				finish();
			}
		});
	}
}