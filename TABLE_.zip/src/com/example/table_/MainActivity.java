package com.example.table_;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		int[] Mon = { R.id.Mon1st, R.id.Mon2nd, R.id.Mon3rd, R.id.Mon4th,
				R.id.Mon5th, R.id.Mon6th, R.id.Mon7th, R.id.Mon8th,
				R.id.Mon9th, R.id.Mon10th, R.id.Mon11th };
		TextView[] MonArr = new TextView[11];
		for (int i = 0; i < MonArr.length; i++) {
			MonArr[i] = (TextView) findViewById(Mon[i]);
		}

		MonArr[0].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "1";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[1].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "2";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[2].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "3";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[3].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "4";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);
			}

		});
		MonArr[4].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "5";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[5].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "6";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[6].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "7";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[7].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "8";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[8].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "9";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[9].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "10";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		MonArr[10].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "11";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});

		int[] Tue = { R.id.Tue1st, R.id.Tue2nd, R.id.Tue3rd, R.id.Tue4th,
				R.id.Tue5th, R.id.Tue6th, R.id.Tue7th, R.id.Tue8th,
				R.id.Tue9th, R.id.Tue10th, R.id.Tue11th };
		TextView[] TueArr = new TextView[11];
		for (int i = 0; i < TueArr.length; i++) {
			TueArr[i] = (TextView) findViewById(Tue[i]);
		}
		TueArr[0].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "1";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[1].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "2";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[2].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "3";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);
			}

		});
		TueArr[3].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "4";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[4].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "5";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[5].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "6";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[6].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "7";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[7].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "8";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[8].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "9";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[9].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "10";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		TueArr[10].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "ȭ";
				String time = "11";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});

		/*
		 * Tue1 = (TextView) findViewById(R.id.Tue1st); Tue2 = (TextView)
		 * findViewById(R.id.Tue2nd); Tue3 = (TextView)
		 * findViewById(R.id.Tue3rd); Tue4 = (TextView)
		 * findViewById(R.id.Tue4th); Tue5 = (TextView)
		 * findViewById(R.id.Tue5th); Tue6 = (TextView)
		 * findViewById(R.id.Tue6th); Tue7 = (TextView)
		 * findViewById(R.id.Tue7th); Tue8 = (TextView)
		 * findViewById(R.id.Tue8th); Tue9 = (TextView)
		 * findViewById(R.id.Tue9th); TueA = (TextView)
		 * findViewById(R.id.Tue10th); TueB = (TextView)
		 * findViewById(R.id.Tue11th);
		 */

		int[] Wedn = { R.id.Wedn1st, R.id.Wedn2nd, R.id.Wedn3rd, R.id.Wedn4th,
				R.id.Wedn5th, R.id.Wedn6th, R.id.Wedn7th, R.id.Wedn8th,
				R.id.Wedn9th, R.id.Wedn10th, R.id.Wedn11th };
		TextView[] WednArr = new TextView[11];
		for (int i = 0; i < WednArr.length; i++) {
			WednArr[i] = (TextView) findViewById(Wedn[i]);
		}
		WednArr[0].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "1";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[1].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "2";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[2].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "3";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[3].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "4";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[4].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "5";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[5].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "6";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[6].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "7";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[7].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "8";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[8].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "9";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[9].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "10";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		WednArr[10].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "11";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});

		/*
		 * Wedn1 = (TextView) findViewById(R.id.Wedn1st); Wedn2 = (TextView)
		 * findViewById(R.id.Wedn2nd); Wedn3 = (TextView)
		 * findViewById(R.id.Wedn3rd); Wedn4 = (TextView)
		 * findViewById(R.id.Wedn4th); Wedn5 = (TextView)
		 * findViewById(R.id.Wedn5th); Wedn6 = (TextView)
		 * findViewById(R.id.Wedn6th); Wedn7 = (TextView)
		 * findViewById(R.id.Wedn7th); Wedn8 = (TextView)
		 * findViewById(R.id.Wedn8th); Wedn9 = (TextView)
		 * findViewById(R.id.Wedn9th); WednA = (TextView)
		 * findViewById(R.id.Wedn10th); WednB = (TextView)
		 * findViewById(R.id.Wedn11th);
		 */

		int[] Thur = { R.id.Thur1st, R.id.Thur2nd, R.id.Thur3rd, R.id.Thur4th,
				R.id.Thur5th, R.id.Thur6th, R.id.Thur7th, R.id.Thur8th,
				R.id.Thur9th, R.id.Thur10th, R.id.Thur11th };
		TextView[] ThurArr = new TextView[11];
		for (int i = 0; i < ThurArr.length; i++) {
			ThurArr[i] = (TextView) findViewById(Thur[i]);
		}

		ThurArr[0].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "1";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);
			}

		});
		ThurArr[1].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "2";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[2].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "3";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[3].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "4";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[4].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "5";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[5].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "6";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[6].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "7";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[7].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "8";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[8].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "9";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[9].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "10";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		ThurArr[10].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "11";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});

		/*
		 * Thur1 = (TextView) findViewById(R.id.Thur1st); Thur2 = (TextView)
		 * findViewById(R.id.Thur2nd); Thur3 = (TextView)
		 * findViewById(R.id.Thur3rd); Thur4 = (TextView)
		 * findViewById(R.id.Thur4th); Thur5 = (TextView)
		 * findViewById(R.id.Thur5th); Thur6 = (TextView)
		 * findViewById(R.id.Thur6th); Thur7 = (TextView)
		 * findViewById(R.id.Thur7th); Thur8 = (TextView)
		 * findViewById(R.id.Thur8th); Thur9 = (TextView)
		 * findViewById(R.id.Thur9th); ThurA = (TextView)
		 * findViewById(R.id.Thur10th); ThurB = (TextView)
		 * findViewById(R.id.Thur11th);
		 */

		int[] Fri = { R.id.Fri1st, R.id.Fri2nd, R.id.Fri3rd, R.id.Fri4th,
				R.id.Fri5th, R.id.Fri6th, R.id.Fri7th, R.id.Fri8th,
				R.id.Fri9th, R.id.Fri10th, R.id.Fri11th };
		TextView[] FriArr = new TextView[11];
		for (int i = 0; i < FriArr.length; i++) {
			FriArr[i] = (TextView) findViewById(Fri[i]);
		}

		FriArr[0].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "1";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[1].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "2";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[2].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "3";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[3].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "4";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[4].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "5";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[5].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "6";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[6].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "7";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[7].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "8";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[8].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "9";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[9].setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// create intent to call Activity2
				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "10";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});
		FriArr[10].setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// create intent to call Activity2

				Intent myIntentA1A2 = new Intent(MainActivity.this,
						TableDialog.class);
				// create a container to ship data
				Bundle myData = new Bundle();

				String day = "��";
				String time = "11";
				// add <key,value> data items to the container
				myData.putString("day", day);
				myData.putString("time", time);
				// attach the container to the intent
				myIntentA1A2.putExtras(myData);
				// call Activity2, tell your local listener to wait for response
				startActivity(myIntentA1A2);

			}

		});

	}

	public void getintent() {
		int[] Mon = { R.id.Mon1st, R.id.Mon2nd, R.id.Mon3rd, R.id.Mon4th,
				R.id.Mon5th, R.id.Mon6th, R.id.Mon7th, R.id.Mon8th,
				R.id.Mon9th, R.id.Mon10th, R.id.Mon11th };
		TextView[] MonArr = new TextView[11];
		for (int i = 0; i < MonArr.length; i++) {
			MonArr[i] = (TextView) findViewById(Mon[i]);
		}

		int[] Tue = { R.id.Tue1st, R.id.Tue2nd, R.id.Tue3rd, R.id.Tue4th,
				R.id.Tue5th, R.id.Tue6th, R.id.Tue7th, R.id.Tue8th,
				R.id.Tue9th, R.id.Tue10th, R.id.Tue11th };
		TextView[] TueArr = new TextView[11];
		for (int i = 0; i < TueArr.length; i++) {
			TueArr[i] = (TextView) findViewById(Tue[i]);
		}

		int[] Wedn = { R.id.Wedn1st, R.id.Wedn2nd, R.id.Wedn3rd, R.id.Wedn4th,
				R.id.Wedn5th, R.id.Wedn6th, R.id.Wedn7th, R.id.Wedn8th,
				R.id.Wedn9th, R.id.Wedn10th, R.id.Wedn11th };
		TextView[] WednArr = new TextView[11];
		for (int i = 0; i < WednArr.length; i++) {
			WednArr[i] = (TextView) findViewById(Wedn[i]);
		}

		int[] Thur = { R.id.Thur1st, R.id.Thur2nd, R.id.Thur3rd, R.id.Thur4th,
				R.id.Thur5th, R.id.Thur6th, R.id.Thur7th, R.id.Thur8th,
				R.id.Thur9th, R.id.Thur10th, R.id.Thur11th };
		TextView[] ThurArr = new TextView[11];
		for (int i = 0; i < ThurArr.length; i++) {
			ThurArr[i] = (TextView) findViewById(Thur[i]);
		}

		int[] Fri = { R.id.Fri1st, R.id.Fri2nd, R.id.Fri3rd, R.id.Fri4th,
				R.id.Fri5th, R.id.Fri6th, R.id.Fri7th, R.id.Fri8th,
				R.id.Fri9th, R.id.Fri10th, R.id.Fri11th };
		TextView[] FriArr = new TextView[11];
		for (int i = 0; i < FriArr.length; i++) {
			FriArr[i] = (TextView) findViewById(Fri[i]);
		}
		
		Intent myLocalIntent = getIntent();
		// look into the bundle sent to Activity2 for data items
		Bundle myBundle = myLocalIntent.getExtras();

		String cName = myBundle.getString("cName");
		String cDay = myBundle.getString("cDay");
		String cTime = myBundle.getString("cTime");
		int n = Integer.valueOf(cTime);
		if (cDay.equals("��")) {
			for (int i = 0; i < 11; i++) {

				if (n == i + 1) {
					MonArr[n - 1].setText(cName);
				}
			}
		} else if (cDay.equals("ȭ")) {
			for (int i = 0; i < 11; i++) {

				if (n == i + 1) {
					TueArr[n - 1].setText(cName);
				}
			}
		} else if (cDay.equals("��")) {
			for (int i = 0; i < 11; i++) {

				if (n == i + 1) {
					WednArr[n - 1].setText(cName);
				}
			}
		} else if (cDay.equals("��")) {
			for (int i = 0; i < 11; i++) {

				if (n == i + 1) {
					ThurArr[n - 1].setText(cName);
				}
			}
		} else if (cDay.equals("��")) {
			for (int i = 0; i < 11; i++) {

				if (n == i + 1) {
					FriArr[n - 1].setText(cName);
				}
			}
		}

	}
}
