package com.example.table_;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Input extends Activity implements OnClickListener {
	EditText className;
	EditText day;
	EditText time;
	EditText professor;
	EditText classRoom;
	Button OK;
	Button Cancel;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main2);
		
		day = (EditText) findViewById(R.id.day);
		time = (EditText) findViewById(R.id.time);
		
		// pick call made to Activity2 via Intent
		Intent myLocalIntent = getIntent();
		// look into the bundle sent to Activity2 for data items
		Bundle myBundle = myLocalIntent.getExtras();
		
		day.setText(myBundle.getString("day"));
		time.setText(myBundle.getString("time"));
		
		OK = (Button) findViewById(R.id.OK1);
		OK.setOnClickListener(this);

		Cancel = (Button) findViewById(R.id.Cancel1);
		Cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
			}
		});

	}

	@Override
	public void onClick(View v) {
		// close current screen - terminate Activity2
		className = (EditText) findViewById(R.id.ClassName);
		day = (EditText) findViewById(R.id.day);
		time = (EditText) findViewById(R.id.time);
		
		String cName = className.getText().toString();
		String cDay = day.getText().toString();
		String cTime = time.getText().toString();

		// create intent to call Activity2
		// pick call made to Activity2 via Intent
		Intent myLocalIntent = getIntent();

		// look into the bundle sent to Activity2 for data items
		Bundle myBundle = myLocalIntent.getExtras();
		
		myBundle.getString("day");
		myBundle.getString("time");
		myLocalIntent.putExtras(myBundle);
		
		Intent i = new Intent(Input.this, MainActivity.class);
		Bundle myData = new Bundle();
		
		// add <key,value> data items to the container
		myData.putString("cName", cName);
		myData.putString("cDay", cDay);
		myData.putString("cTime", cTime);
		
		i.putExtras(myData);

		MainActivity ma = new MainActivity();
		
		ma.getintent();
		
		finish();
	}

}
