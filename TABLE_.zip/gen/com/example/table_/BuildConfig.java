/** Automatically generated file. DO NOT MODIFY */
package com.example.table_;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}